IceCream Pro POS Android project

This is an Android Studio Gradle project. It contains a WebView app with an offline HTML POS interface.

Build requirements: Android Studio, JDK 17, Android SDK platform 35, Gradle 8.9 or compatible. Open the extracted folder as an Android Studio project and build app > assembleDebug.

Important: this ZIP is source code, not a prebuilt APK. Data is stored in local WebView storage on the device; uninstalling or clearing app data can erase it. Export backups regularly. This project has not been independently tested on a physical device.
