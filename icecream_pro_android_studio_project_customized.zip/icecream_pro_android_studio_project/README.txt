IceCream Pro POS Android project

This is an Android Studio Gradle project. It contains a WebView app with an offline HTML POS interface.

Build requirements: Android Studio, JDK 17, Android SDK platform 35, Gradle 8.9 or compatible. Open the extracted folder as an Android Studio project and build app > assembleDebug.

Important: this ZIP is source code, not a prebuilt APK. Data is stored in local WebView storage on the device; uninstalling or clearing app data can erase it. Export backups regularly. This project has not been independently tested on a physical device.


Updated combined features: product photo upload/edit, daily and monthly reports, workday tracking, and invoice-wise multi-item stock receiving. Enter invoice number/supplier/date, add all items to the draft, then save invoice to add quantities to each product main stock. Existing refills/sales/damages remain stored locally on device; export a backup before replacing an installed app.


Default starter catalog: 17 unique ice-cream items, deduplicated and assigned to Cones, Cups, Sticks, and Cubes. Selling price, cost price, and starting stock are set to 0 because the owner must enter the actual shop values. Existing unused sample products are migrated to this catalog on app launch; existing activity/product data is preserved.

Additional settings: editable shop/app name in the app header, live date/time, selectable visual theme, saved shop address, optional QR payment image/note, and GPS-based sale location when permission and location are available. If internet/GPS is unavailable, POS billing and stock functions remain offline; address may fall back to saved shop address or coordinates. Tap & Pay requires an external compatible payment terminal/provider; this app records the chosen payment method but does not process NFC payments itself.
